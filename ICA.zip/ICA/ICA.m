% Clear all variables except 'data'
clearvars -except data

% Z-score normalization and correlation matrix
data_z = zscore(data); 
C = corr(data_z); 

% Set diagonal elements to zero
C(1:length(C)+1:end) = 0;

% Plot the correlation matrix
figure;
imagesc(C); 
colorbar;
xlabel('Neuron Number'); 
ylabel('Neuron Number');

% Transpose the data
data = data';

% Set options for assembly_patterns
opts.threshold.method = 'MarcenkoPastur'; 
opts.Patterns.method = 'ICA'; 
opts.Patterns.number_of_iterations = 500;

% Calculate patterns and activities
Patterns = assembly_patterns(data, opts); 
Activities = assembly_activity(Patterns, data);

% Plot data and activities
figure;
subplot(2,1,1);
imagesc(data); 
title('Data');

subplot(2,1,2);
plot(Activities');
title('Activities');

% Get the number of patterns
N = size(Patterns, 2); 
figure
for i = 1:N
   subplot(N, 1, i);
   stem(Patterns(:, i), 'filled');
   title(['Pattern ', num2str(i)]);
end
